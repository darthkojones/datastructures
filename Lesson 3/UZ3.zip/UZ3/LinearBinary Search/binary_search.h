#ifndef BINARY_SEARCH_H
#define BINARY_SEARCH_H

int binarySearch(const int arr[], int size, int target);

#endif // BINARY_SEARCH_H
