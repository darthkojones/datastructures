#ifndef LINEAR_SEARCH_H
#define LINEAR_SEARCH_H

int linearSearch(const int arr[], int size, int target);

#endif // LINEAR_SEARCH_H
