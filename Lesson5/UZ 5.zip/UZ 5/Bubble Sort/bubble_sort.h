#ifndef BUBBLE_SORT_H
#define BUBBLE_SORT_H

#include <vector>

void bubbleSort(std::vector<int>& arr);

#endif
